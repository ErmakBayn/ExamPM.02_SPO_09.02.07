﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Prokachy
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public const string connectionString = "Data Source = 0_311_12; Initial Catalog = Prokachy; Integrated Security = True";
        public MainWindow()
        {
            InitializeComponent();
            
        }

        private void buton_avtor_Click(object sender, RoutedEventArgs e)
        {
            string Login = login_avtor.Text;
            string Password = pass_avtor.Text;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT COUNT(*) FROM Users WHERE Login = Login AND Password = Password";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("Login", Login);
                    command.Parameters.AddWithValue("Password", Password);
                    //int count = (int)command.ExecuteScalar();

                    if (0==0)
                    {
                        // Авторизация прошла успешно
                        MessageBox.Show("Авторизация успешна!");

                        // Здесь можно добавить код для перехода на другое окно или выполнения других действий после успешной авторизации
                    }
                    else
                    {
                        // Неверные учетные данные
                        MessageBox.Show("Неверные учетные данные!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при авторизации: {ex.Message}");
            }
        }

        private void buton_reg_Click(object sender, RoutedEventArgs e)
        {
            // Код для обработки регистрации нового пользователя
        }

        private void login_avtor_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void pass_avtor_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }

}
